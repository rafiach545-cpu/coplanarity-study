#!/usr/bin/env bash
# G13 server run, bundle v2 (2026-11-24): Athena string-model systematic on the 13.6 TeV B08 EW signal, paired with Eq. 3 (DOP853).
# EW 400 / 800 / 1200 GeV, Lambda = 4, 7, 10 keV, all triggered events of the 07 10k samples (c00-c04); both models with the same lambda
# list (B08 keys the SCT-smearing streams by the position in the list).
# Usage:  CONDA_ENV=<env with Geant4> bash run_g13.sh <regen base, e.g. ~/regen_production/base>          (full run)
#         CONDA_ENV=<env> MODE=smoke bash run_g13.sh <base>    (checks + 6 events of EW 800 GeV vs the laptop reference in ref/)
#         CONDA_ENV=<env> MODE=check bash run_g13.sh <base>    (environment, build and one Geant4 event only)
# CONDA_ENV defaults to the active conda env ($CONDA_DEFAULT_ENV), else g4. The env needs Geant4 11.4 with its data sets, numpy,
# pandas, numba, uproot (the conda env of hep_tools/g4_setup/g4_lock_linux64.txt).
# v2 changes (workflow only): environment and Geant4-data checks with clear messages; one Geant4 test event with its log; a Geant4
# failure stops G13 with the quirksim output (v1 counted it as integration_fail, so the summary failed on a missing 'fiducial' column);
# nothing is copied into <base> (G13 imports B08 via G13_D09); the log tail is printed when a step fails.
# Writes only into this folder (out/, out_smoke/ or out_check/). No git, nothing deleted except G13's own per-event temporary folders.
set -euo pipefail
R="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE="$(cd "${1:?usage: run_g13.sh <regen base>}" && pwd)"
MODE="${MODE:-full}"
case "$MODE" in full) OUT="$R/out" ;; smoke) OUT="$R/out_smoke" ;; check) OUT="$R/out_check" ;; *) echo "MODE must be full, smoke or check"; exit 2 ;; esac
[ -e "$OUT" ] && { echo "$OUT exists: move it aside first (nothing is overwritten)"; exit 2; }
die() { echo "STOP: $*" >&2; exit 3; }
tailf() { echo "---- last lines of $1 ----" >&2; tail -n 40 "$1" >&2; echo "----" >&2; }

# ---- environment
ENV_NAME="${CONDA_ENV:-${CONDA_DEFAULT_ENV:-g4}}"
CB="$(conda info --base 2>/dev/null)" || die "conda not found in PATH"
set +u; source "$CB/etc/profile.d/conda.sh"
conda activate "$ENV_NAME" || { set -u; die "conda activate $ENV_NAME failed; envs: $(conda env list | awk '!/^#/ {print $1}' | tr '\n' ' ')"; }
set -u
[ "$(basename "$CONDA_PREFIX")" = "$ENV_NAME" ] || [ "$CONDA_PREFIX" = "$ENV_NAME" ] || die "active env is $CONDA_PREFIX, expected $ENV_NAME"
PY="$CONDA_PREFIX/bin/python"; [ -x "$PY" ] || die "no python in $CONDA_PREFIX"
"$PY" -c "import numpy, pandas, numba, uproot" 2>/dev/null || die "env $ENV_NAME lacks numpy/pandas/numba/uproot: $("$PY" -c 'import numpy, pandas, numba, uproot' 2>&1 | tail -1)"
command -v geant4-config >/dev/null || die "geant4-config not in env $ENV_NAME (Geant4 not installed there)"
G4V="$(geant4-config --version)"
NMISS=0
while read -r name var path; do
  [ -n "${!var:-}" ] || { echo "Geant4 data: $var ($name) not set" >&2; NMISS=$((NMISS + 1)); continue; }
  [ -d "${!var}" ] || { echo "Geant4 data: $var=${!var} is not a folder" >&2; NMISS=$((NMISS + 1)); }
done < <(geant4-config --datasets)
[ "$NMISS" = 0 ] || die "$NMISS Geant4 data sets missing in env $ENV_NAME (conda activate sets them when the geant4-data packages are installed)"

# ---- inputs (read only)
D09="$BASE/09_stage1_run2_ideal_zvv_background"
[ -f "$D09/B08_signal_cleaning_scan.py" ] || die "no B08 in $D09"
for m in 400 800 1200; do
  n=$(compgen -G "$BASE/hep_tools/07_large_runs/EW_${m}gev_c0[0-4]/Events/*/tag_1_pythia8_events.hepmc.gz" | wc -l)
  [ "$n" = 5 ] || die "EW $m GeV: $n HepMC chunks, expected 5"
done
mkdir -p "$OUT/logs" "$OUT/tmp"

# ---- build QuirkPheno_fix (in this folder)
if [ ! -x "$R/QuirkPheno_fix/build/quirksim/quirksim" ]; then
  echo "building QuirkPheno_fix (log: $OUT/logs/build.log)"
  { cmake -S "$R/QuirkPheno_fix" -B "$R/QuirkPheno_fix/build" -DCMAKE_PREFIX_PATH="$CONDA_PREFIX" && cmake --build "$R/QuirkPheno_fix/build" -j8; } \
    > "$OUT/logs/build.log" 2>&1 || { tailf "$OUT/logs/build.log"; die "build failed"; }
fi
export QUIRKPHENO_FIX="$R/QuirkPheno_fix" COPLANARITY_BASE="$BASE" HEP_TOOLS="$BASE/hep_tools" SIGNAL_10K_RUNS="$BASE/hep_tools/07_large_runs" \
       G13_D09="$D09" G13_TMP="$OUT/tmp" PYTHONDONTWRITEBYTECODE=1
export LD_LIBRARY_PATH="$R/QuirkPheno_fix/build/quirkcore:${LD_LIBRARY_PATH:-}"

# ---- one Geant4 event (EW 800 GeV, 4 keV, the first pair of 01_signal_generation/ew_quirk_pair_momenta_800gev_4kev.csv, as G01),
#      so that a Geant4 problem shows here with its own log
cat > "$OUT/logs/g4_test.mac" <<EOF
/quirk/secondOrderField true
/qsim/field/deltaIntersection 1e-6 mm
/quirk/maxBoost 0.01
/quirk/mass 800 GeV
/quirk/lambda 4000 eV
/qsim/card $R/ideal8_vacuum.card
/qsim/gen/mode gun
/qsim/killSecondaries true
/qsim/out/towers false
/qsim/maxTime 25.05 ns
/qsim/gun/p1 33.130384140039475 416.52193247200114 1275.152301832106 GeV
/qsim/gun/p2 -48.433436771854105 -274.949943192303 70.04901761155496 GeV
/qsim/gun/vertex 0 0 0 mm
/run/initialize
/run/beamOn 1
EOF
"$R/QuirkPheno_fix/build/quirksim/quirksim" -m "$OUT/logs/g4_test.mac" -t 1 -s 7 -o "$OUT/logs/g4_test.root" > "$OUT/logs/g4_test.log" 2>&1 \
  || { tailf "$OUT/logs/g4_test.log"; die "Geant4 test event failed (see above)"; }
grep -q "quirksim: event 0" "$OUT/logs/g4_test.log" || { tailf "$OUT/logs/g4_test.log"; die "Geant4 test event wrote no event line"; }
NW="${NW:-$(( $(nproc) - 4 ))}"; [ "$NW" -ge 1 ] || NW=1
{ date; hostname; echo "nproc $(nproc), workers $NW"; echo "conda env $ENV_NAME ($CONDA_PREFIX), Geant4 $G4V"; "$PY" --version
  "$PY" -c "import numpy, pandas, numba, uproot; print('numpy', numpy.__version__, 'pandas', pandas.__version__, 'numba', numba.__version__, 'uproot', uproot.__version__)"
  grep "quirksim: event 0" "$OUT/logs/g4_test.log"
  md5sum "$R/G13_athena_b08_scan.py" "$R/ideal8_vacuum.card" "$D09/B08_signal_cleaning_scan.py" "$D09/B05_signal_full_event.py" \
         "$BASE/04_detector_sim/trajectory_to_hits.py" "$BASE/03_trajectory_sim/quirk_trajectory_dop853.py"
  (cd "$R/QuirkPheno_fix" && git rev-parse HEAD 2>/dev/null; git diff --stat 2>/dev/null | tail -1); } > "$OUT/CODE_INFO.txt" 2>&1
echo "environment OK: env $ENV_NAME, Geant4 $G4V, data sets complete, Geant4 test event OK ($(grep -o 'hits [0-9]*' "$OUT/logs/g4_test.log" | head -1))"
[ "$MODE" = check ] && { echo "check done: $OUT"; exit 0; }

G13="$PY $R/G13_athena_b08_scan.py"
run13() {  # mass model nmax(or "") log
  local log="$4"
  if [ -n "$3" ]; then $G13 "$1" --model "$2" --lambdas 4,7,10 --nmax "$3" --workers 3 --out "$OUT" > "$log" 2>&1
  else $G13 "$1" --model "$2" --lambdas 4,7,10 --workers "$NW" --out "$OUT" > "$log" 2>&1; fi
}
if [ "$MODE" = smoke ]; then
  for model in eq3 athena; do
    run13 800 "$model" 6 "$OUT/logs/smoke_$model.log" || { tailf "$OUT/logs/smoke_$model.log"; die "smoke $model failed"; }
  done
  "$PY" - "$R/ref" "$OUT" <<'EOF'
import sys, pandas as pd
ref, out = sys.argv[1:3]; bad = 0
for model in ("eq3", "athena"):
    a = pd.read_csv(f"{ref}/G13_{model}_EW_800gev_L4-7-10_n6.csv"); b = pd.read_csv(f"{out}/G13_{model}_EW_800gev_L4-7-10_n6.csv")
    cols = ["integration_fail", "fiducial", "qrk_sr_pass", "iso20_sr_pass", "all_sr_pass"]
    miss = [c for c in cols + ["qrk_sel_ds_cm"] if c not in b.columns]
    if miss:
        print(f"SMOKE {model}: FAIL  columns missing in the new CSV: {miss}"); bad += 1; continue
    m = a.merge(b, on=["chunk", "event", "lambda_keV"], suffixes=("_ref", "_new"))
    nd = {c: int((m[c + "_ref"].astype(str) != m[c + "_new"].astype(str)).sum()) for c in cols}
    dds = float(((m.qrk_sel_ds_cm_ref - m.qrk_sel_ds_cm_new).abs() * 1e4).max())
    ok = len(m) == len(a) == len(b) and sum(nd.values()) == 0 and not (dds > 1e-3)
    bad += not ok
    print(f"SMOKE {model}: {'PASS' if ok else 'FAIL'}  rows {len(m)}/{len(a)}, decision differences {nd}, max |ds| difference {dds:.3g} um")
sys.exit(1 if bad else 0)
EOF
  echo "smoke done: $OUT"; exit 0
fi
for m in 800 400 1200; do
  for model in eq3 athena; do
    echo "$(date) EW $m GeV $model (workers $NW)"
    run13 "$m" "$model" "" "$OUT/logs/G13_${model}_EW_${m}.log" || { tailf "$OUT/logs/G13_${model}_EW_${m}.log"; echo "FAILED: EW $m $model (log above)"; }
  done
done
echo "$(date) G13 done: $OUT"; ls -l "$OUT"/*.csv
